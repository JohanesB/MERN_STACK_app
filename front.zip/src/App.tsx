import "./App.css";

import Table from "./components/Table";

function App() {
  return (
    <>
      <div className="container">
        <Table></Table>
      </div>
    </>
  );
}

export default App;
