export interface GoalModel {
  name: string;
  date_of_birth: string;
  gender: string;
  salary: number;
  id?: number;
}

export interface Goal extends GoalModel {
  _id: string;
}

export interface GoalState {
  goals: Array<Goal>;
  isLoading: boolean;
}
