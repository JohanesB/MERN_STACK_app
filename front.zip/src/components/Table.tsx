import { useEffect } from "react";
import { Goal } from "../redux/types";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../redux";

export default function Table() {
  const goal: Goal[] = useSelector(
    (state: RootState) => state.goalReducer.goals
  );
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch({
      type: "goals/fetch_goal",
    });
  }, []);

  console.log("this is from the table" + goal)
  return (
    <div>
      <h2>this is data we are going to show you</h2>
      {goal.map((item, index) => {
        return (
          <div key={index}>
            <span>{item.name} </span>
            <span>{item.gender}</span>
            <span>{item.date_of_birth}</span>
            <span>{item.salary}</span>
          </div>
        );
      })}
    </div>
  );
}
